# Supabase setup (OutYah)

Updated: **5 August 2026**

## 1. Run schema (required once)

1. Open your project SQL editor in the Supabase dashboard.
2. Apply migrations in order:

| File | Purpose |
|------|---------|
| [`001_init.sql`](./001_init.sql) | Core tables, RLS, media bucket |
| [`002_events_schedule.sql`](./002_events_schedule.sql) | Event `starts_at` / `ends_at` / recurring |
| [`003_place_reviews.sql`](./003_place_reviews.sql) | `place_reviews` + review_count trigger |

Or paste [`full_setup.sql`](./full_setup.sql) for the combined initial schema, then run `002` and `003` if they are not already included.

Optional sample rows: [`seed.sql`](./seed.sql) (legacy mock catalog — prefer live Kingston/Google seed scripts in the repo).

## 2. Auth settings

In **Authentication → Providers → Email**:

- Enable Email provider
- For local/demo speed, you can disable **Confirm email**

## 3. Create an admin

1. Sign up in the app at `/auth`
2. In SQL Editor:

```sql
update profiles
set role = 'admin'
where id = '<your-user-uuid>';
```

Or by email:

```sql
update profiles
set role = 'admin'
where id = (
  select id from auth.users where email = 'you@example.com'
);
```

3. Open `/admin` (admin links also appear in the main nav when `role = admin`)

## 4. Vercel env vars

Add these in the Vercel project settings (Production + Preview):

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_GOOGLE_MAPS_API_KEY`

Server-only (local scripts / CI — **never** ship to the browser):

- `SUPABASE_SERVICE_ROLE_KEY`
- `DATABASE_URL` (or `SUPABASE_DB_PASSWORD`) for DDL scripts

Redeploy after saving.

## 5. Live data scripts (preferred over mock seed)

```bash
# Kingston venues
bun scripts/seed_kingston_places.mjs
bun scripts/seed_place_photos_from_google.mjs

# Event schedule + Independence-week sample events
bun scripts/seed_jamaica_events.mjs

# Google-only place reviews into place_reviews
bun scripts/seed_real_place_reviews.mjs
```

## 6. Review model notes

- `place_reviews.source` is one of: `outyah`, `google`, `instagram`, `tripadvisor`, `yelp`
- Public can read all reviews; authenticated users may insert **OutYah** reviews only
- Venue UI badges show **via Google** / **via OutYah**, etc.
- Instagram has no public venue-review API — do not expect IG review sync

Never commit the service role key. The anon key is safe for the browser when RLS is enabled.
